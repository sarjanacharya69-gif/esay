# BG Video Scheduler V2 - Android Example

This project demonstrates:
- Camera2 + MediaRecorder recording inside a ForegroundService.
- Scheduling daily start/stop recording using AlarmManager (time zone aware).
- Target storage per hour (GB) converted to bitrate and enforced via MediaRecorder.setMaxFileSize(),
  with auto-splitting when max file size is reached.
- Simple UI to set start/stop times, timezone, and GB/hour target.

Important:
- This is a starter project. Camera2 and background recording behave differently across devices.
- The service assumes CAMERA and RECORD_AUDIO permissions have been granted before starting.
- For modern Android use MediaStore/scoped storage rather than WRITE_EXTERNAL_STORAGE.
- Thorough testing required before release. Respect privacy & Play Store policies.

Open the folder in Android Studio to build. The sample uses Kotlin and targets SDK 34.
