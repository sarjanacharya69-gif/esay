package com.example.bgvideoschedulerv2

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.MediaRecorder
import android.os.Binder
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RecordingService : Service() {

    companion object {
        const val ACTION_START = "com.example.bgvideoschedulerv2.action.START"
        const val ACTION_STOP = "com.example.bgvideoschedulerv2.action.STOP"
        const val CHANNEL_ID = "bg_record_channel_v2"
        const val NOTIF_ID = 3456
        const val EXTRA_GB_PER_HOUR = "extra_gb_per_hour"
        const val TAG = "RecordingServiceV2"
    }

    private val binder = LocalBinder()

    private var cameraDevice: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var recorder: MediaRecorder? = null
    private var cameraManager: CameraManager? = null
    private var backgroundHandler: Handler? = null
    private var backgroundThread: HandlerThread? = null

    // target bytes per hour, default 1.5 GB
    private var bytesPerHour: Long = (1.5 * 1024 * 1024 * 1024).toLong()

    override fun onCreate() {
        super.onCreate()
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val gb = intent.getDoubleExtra(EXTRA_GB_PER_HOUR, 1.5)
                bytesPerHour = (gb * 1024.0 * 1024.0 * 1024.0).toLong()
                startRecording()
            }
            ACTION_STOP -> stopRecording()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = binder

    inner class LocalBinder : Binder() {
        fun getService(): RecordingService = this@RecordingService
    }

    private fun startRecording() {
        startBackgroundThread()
        val notification = buildNotification("Recording...")
        startForeground(NOTIF_ID, notification)
        try {
            val cameraId = cameraManager!!.cameraIdList.first()
            cameraManager!!.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    try {
                        setupMediaRecorder()
                        val surface = recorder!!.surface
                        val targets = listOf(surface)
                        camera.createCaptureSession(targets, object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(session: CameraCaptureSession) {
                                this@RecordingService.session = session
                                try {
                                    val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                                    builder.addTarget(surface)
                                    session.setRepeatingRequest(builder.build(), null, backgroundHandler)
                                    recorder!!.start()
                                } catch (e: Exception) { e.printStackTrace() }
                            }
                            override fun onConfigureFailed(session: CameraCaptureSession) {}
                        }, backgroundHandler)
                    } catch (e: Exception) { e.printStackTrace() }
                }
                override fun onDisconnected(camera: CameraDevice) { camera.close(); cameraDevice = null }
                override fun onError(camera: CameraDevice, error: Int) { camera.close(); cameraDevice = null }
            }, backgroundHandler)
        } catch (e: SecurityException) {
            Log.e(TAG, "Missing camera permission", e)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupMediaRecorder() {
        if (recorder == null) recorder = MediaRecorder()
        val outFile = createOutputFile()
        recorder!!.apply {
            reset()
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(outFile.absolutePath)
            // compute bitrate based on bytesPerHour (bits/sec) minus audio
            val audioBps = 128_000 // 128 kbps audio
            val bytesPerSec = bytesPerHour / 3600.0
            val bitsPerSec = (bytesPerSec * 8.0).toLong()
            val videoBps = (bitsPerSec - audioBps).coerceAtLeast(500_000L) // at least 500kbps
            setVideoEncodingBitRate(videoBps.toInt())
            setVideoFrameRate(30)
            setVideoSize(1920, 1080)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            // set max file size so we split into approx bytesPerHour files
            setMaxFileSize(bytesPerHour)
            setOnInfoListener { mr, what, extra ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) {
                    // restart recording into a new file
                    try {
                        mr.stop()
                    } catch (e: Exception) { e.printStackTrace() }
                    mr.reset()
                    // prepare new file and start again
                    val newFile = createOutputFile()
                    try {
                        mr.setOutputFile(newFile.absolutePath)
                        // must set sources/encoders again if recorder was reset; for simplicity recreate recorder
                        recreateRecorderAndStart(newFile)
                    } catch (ex: Exception) { ex.printStackTrace() }
                }
            }
            prepare()
        }
    }

    private fun recreateRecorderAndStart(file: File) {
        // release old
        try { recorder?.release() } catch (e: Exception) {}
        recorder = MediaRecorder()
        recorder!!.apply {
            reset()
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(file.absolutePath)
            val audioBps = 128_000
            val bytesPerSec = bytesPerHour / 3600.0
            val bitsPerSec = (bytesPerSec * 8.0).toLong()
            val videoBps = (bitsPerSec - audioBps).coerceAtLeast(500_000L)
            setVideoEncodingBitRate(videoBps.toInt())
            setVideoFrameRate(30)
            setVideoSize(1920, 1080)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setMaxFileSize(bytesPerHour)
            setOnInfoListener { mr, what, extra ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) {
                    try { mr.stop() } catch (e: Exception) {}
                    mr.reset()
                }
            }
            try {
                prepare()
                // start a new capture session that uses the new recorder surface
                val surface = recorder!!.surface
                cameraDevice?.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        this@RecordingService.session = session
                        try {
                            val builder = cameraDevice!!.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                            builder.addTarget(surface)
                            session.setRepeatingRequest(builder.build(), null, backgroundHandler)
                            recorder!!.start()
                        } catch (e: Exception) { e.printStackTrace() }
                    }
                    override fun onConfigureFailed(session: CameraCaptureSession) {}
                }, backgroundHandler)
            } catch (e: Exception) { e.printStackTrace() }
        }
    }

    private fun createOutputFile(): File {
        val dcim = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
        val dir = File(dcim, "AutoRecordingsV2")
        if (!dir.exists()) dir.mkdirs()
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return File(dir, "VID_$timestamp.mp4")
    }

    private fun stopRecording() {
        try {
            session?.close(); session = null
            cameraDevice?.close(); cameraDevice = null
            try { recorder?.stop() } catch (e: Exception) {}
            try { recorder?.release() } catch (e: Exception) {}
            recorder = null
        } catch (e: Exception) { e.printStackTrace() }
        stopForeground(true)
        stopSelf()
        stopBackgroundThread()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRecording()
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBg").also { it.start() }
        backgroundHandler = Handler(backgroundThread!!.looper)
    }
    private fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
            backgroundThread = null
            backgroundHandler = null
        } catch (e: InterruptedException) { e.printStackTrace() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CHANNEL_ID, "BG Recording V2", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, RecordingService::class.java).apply { action = ACTION_STOP }
        val piFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val stopPending = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or piFlags)
        val mainIntent = Intent(this, MainActivity::class.java)
        val mainPending = PendingIntent.getActivity(this, 0, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT or piFlags)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("BG Video Scheduler V2")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(mainPending)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPending)
            .build()
    }
}
