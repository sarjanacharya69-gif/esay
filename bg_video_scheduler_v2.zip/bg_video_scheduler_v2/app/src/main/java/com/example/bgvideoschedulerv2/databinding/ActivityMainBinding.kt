package com.example.bgvideoschedulerv2.databinding

import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

class ActivityMainBinding(val root: View) {
    val tvStatus: TextView = root.findViewById(android.R.id.text1)
    val btnManualStart: Button = root.findViewById(android.R.id.button1)
    val btnManualStop: Button = root.findViewById(android.R.id.button2)
    val btnStartTime: Button = root.findViewById(android.R.id.button3)
    val btnStopTime: Button = root.findViewById(android.R.id.button4)
    val spinnerTimeZone: Spinner = root.findViewById(android.R.id.empty)
    val etGbPerHour: EditText = root.findViewById(android.R.id.edit)
    val btnSetSchedule: Button = root.findViewById(android.R.id.button5)
    val btnCancelSchedule: Button = root.findViewById(android.R.id.button6)

    companion object {
        fun inflate(inflater: android.view.LayoutInflater): ActivityMainBinding {
            val v = inflater.inflate(com.example.bgvideoschedulerv2.R.layout.activity_main, null)
            return ActivityMainBinding(v)
        }
    }
}
