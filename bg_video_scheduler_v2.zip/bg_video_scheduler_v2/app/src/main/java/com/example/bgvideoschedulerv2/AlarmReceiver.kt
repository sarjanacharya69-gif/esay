package com.example.bgvideoschedulerv2

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_START_RECORD = "com.example.bgvideoschedulerv2.ACTION_START_RECORD"
        const val ACTION_STOP_RECORD = "com.example.bgvideoschedulerv2.ACTION_STOP_RECORD"
        const val EXTRA_GB_PER_HOUR = "extra_gb_per_hour"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_START_RECORD -> {
                val gb = intent.getDoubleExtra(EXTRA_GB_PER_HOUR, 1.5)
                val svc = Intent(context, RecordingService::class.java).apply {
                    action = RecordingService.ACTION_START
                    putExtra(RecordingService.EXTRA_GB_PER_HOUR, gb)
                }
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(svc)
                } else {
                    context.startService(svc)
                }
            }
            ACTION_STOP_RECORD -> {
                val svc = Intent(context, RecordingService::class.java).apply { action = RecordingService.ACTION_STOP }
                context.startService(svc)
            }
        }
    }
}
