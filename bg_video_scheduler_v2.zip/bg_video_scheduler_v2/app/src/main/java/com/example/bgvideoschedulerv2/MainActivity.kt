package com.example.bgvideoschedulerv2

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.TimePicker
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.bgvideoschedulerv2.databinding.ActivityMainBinding
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var startLocalTime: LocalTime = LocalTime.of(20, 12)
    private var stopLocalTime: LocalTime = LocalTime.of(0, 0)
    private var selectedZoneId: ZoneId = ZoneId.systemDefault()
    private var gbPerHour: Double = 1.5

    private val permsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val ok = perms["android.permission.CAMERA"] == true &&
                perms["android.permission.RECORD_AUDIO"] == true
        if (!ok) {
            binding.tvStatus.text = "Status: Permissions required"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        permsLauncher.launch(arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO))

        binding.btnManualStart.setOnClickListener { startRecordingService(gbPerHour) }
        binding.btnManualStop.setOnClickListener { stopRecordingService() }

        binding.btnStartTime.setOnClickListener { showTimePicker(true) }
        binding.btnStopTime.setOnClickListener { showTimePicker(false) }

        val zones = ZoneId.getAvailableZoneIds().toList().sorted()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, zones)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerTimeZone.adapter = adapter
        val defaultPos = zones.indexOf(ZoneId.systemDefault().id)
        binding.spinnerTimeZone.setSelection(if (defaultPos >= 0) defaultPos else 0)

        binding.btnSetSchedule.setOnClickListener {
            val zoneId = ZoneId.of(binding.spinnerTimeZone.selectedItem as String)
            selectedZoneId = zoneId
            val text = binding.etGbPerHour.text.toString()
            gbPerHour = if (text.isNotBlank()) text.toDoubleOrNull() ?: 1.5 else 1.5
            scheduleDailyRecording(startLocalTime, stopLocalTime, zoneId, gbPerHour)
        }

        binding.btnCancelSchedule.setOnClickListener { cancelScheduledRecording() }
    }

    private fun showTimePicker(isStart: Boolean) {
        val tp = TimePicker(this)
        tp.setIs24HourView(false)
        val cur = if (isStart) startLocalTime else stopLocalTime
        tp.hour = cur.hour
        tp.minute = cur.minute

        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(if (isStart) "Select Start Time" else "Select Stop Time")
            .setView(tp)
            .setPositiveButton("OK") { _, _ ->
                val picked = LocalTime.of(tp.hour, tp.minute)
                if (isStart) {
                    startLocalTime = picked
                    binding.btnStartTime.text = "Start: " + picked.format(DateTimeFormatter.ofPattern("hh:mm a"))
                } else {
                    stopLocalTime = picked
                    binding.btnStopTime.text = "Stop: " + picked.format(DateTimeFormatter.ofPattern("hh:mm a"))
                }
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
    }

    private fun scheduleDailyRecording(startLocal: LocalTime, stopLocal: LocalTime, zoneId: ZoneId, gbPerHour: Double) {
        val nowZ = ZonedDateTime.now(zoneId)
        var startZ = nowZ.withHour(startLocal.hour).withMinute(startLocal.minute).withSecond(0).withNano(0)
        if (startZ.isBefore(nowZ)) startZ = startZ.plusDays(1)

        var stopZ = nowZ.withHour(stopLocal.hour).withMinute(stopLocal.minute).withSecond(0).withNano(0)
        if (stopZ.isBefore(nowZ) || stopZ.isEqual(nowZ)) stopZ = stopZ.plusDays(1)

        val startInstant = startZ.toInstant()
        var stopInstant = stopZ.toInstant()
        if (stopInstant.isBefore(startInstant)) stopInstant = stopInstant.plusSeconds(24 * 3600)

        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val startIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_START_RECORD
            putExtra(AlarmReceiver.EXTRA_GB_PER_HOUR, gbPerHour)
        }
        val startPending = PendingIntent.getBroadcast(this, 2001, startIntent, PendingIntent.FLAG_UPDATE_CURRENT or pendingIntentMutabilityFlag())
        setExactAlarm(am, startInstant.toEpochMilli(), startPending)

        val stopIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_STOP_RECORD
        }
        val stopPending = PendingIntent.getBroadcast(this, 2002, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or pendingIntentMutabilityFlag())
        setExactAlarm(am, stopInstant.toEpochMilli(), stopPending)

        binding.tvStatus.text = "Status: Scheduled daily from ${startLocal.format(DateTimeFormatter.ofPattern("hh:mm a"))} to ${stopLocal.format(DateTimeFormatter.ofPattern("hh:mm a"))} (${zoneId.id}), ${gbPerHour} GB/hr"
    }

    private fun pendingIntentMutabilityFlag(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
    }

    private fun setExactAlarm(am: AlarmManager, triggerAtMillis: Long, pi: PendingIntent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }

    private fun cancelScheduledRecording() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val startIntent = Intent(this, AlarmReceiver::class.java).apply { action = AlarmReceiver.ACTION_START_RECORD }
        val stopIntent = Intent(this, AlarmReceiver::class.java).apply { action = AlarmReceiver.ACTION_STOP_RECORD }
        val startPending = PendingIntent.getBroadcast(this, 2001, startIntent, PendingIntent.FLAG_NO_CREATE or pendingIntentMutabilityFlag())
        val stopPending = PendingIntent.getBroadcast(this, 2002, stopIntent, PendingIntent.FLAG_NO_CREATE or pendingIntentMutabilityFlag())
        if (startPending != null) am.cancel(startPending)
        if (stopPending != null) am.cancel(stopPending)
        binding.tvStatus.text = "Status: Schedule canceled"
    }

    private fun startRecordingService(gbPerHour: Double) {
        val intent = Intent(this, RecordingService::class.java).apply {
            action = RecordingService.ACTION_START
            putExtra(RecordingService.EXTRA_GB_PER_HOUR, gbPerHour)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        binding.tvStatus.text = "Status: Recording (manual)"
    }

    private fun stopRecordingService() {
        val intent = Intent(this, RecordingService::class.java)
        intent.action = RecordingService.ACTION_STOP
        startService(intent)
        binding.tvStatus.text = "Status: Stopping..."
    }
}
